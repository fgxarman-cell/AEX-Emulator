package com.armancraft.aex;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private static final int PICK_EXE = 1001;
    private TextView selectedFile;
    private TextView engineStatus;
    private Uri selectedUri;

    static {
        System.loadLibrary("aex_native");
    }

    private native String nativeGetEngineStatus();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private void buildUi() {
        int ink = Color.rgb(29, 39, 54);
        int muted = Color.rgb(100, 113, 130);
        int blue = Color.rgb(48, 105, 220);
        int bg = Color.rgb(246, 248, 252);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(28), dp(22), dp(24));
        scroll.addView(page);

        TextView brand = text("AEX", 34, blue);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        page.addView(brand);

        TextView subtitle = text("Android EXE Emulator", 17, ink);
        subtitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.bottomMargin = dp(22);
        page.addView(subtitle, subParams);

        page.addView(section("GAME LIBRARY", ink));
        TextView intro = text("Choose a Windows .exe file to prepare a launch profile.", 14, muted);
        intro.setPadding(0, dp(8), 0, dp(14));
        page.addView(intro);

        Button choose = new Button(this);
        choose.setText("Choose EXE file");
        choose.setAllCaps(false);
        choose.setTextColor(Color.WHITE);
        choose.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        page.addView(choose, matchWrap());
        choose.setOnClickListener(v -> openExePicker());

        selectedFile = text("No file selected", 14, muted);
        selectedFile.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams fileParams = matchWrap();
        fileParams.topMargin = dp(8);
        page.addView(selectedFile, fileParams);

        Button launch = new Button(this);
        launch.setText("Prepare launch");
        launch.setAllCaps(false);
        page.addView(launch, matchWrap());
        launch.setOnClickListener(v -> {
            if (selectedUri == null) {
                engineStatus.setText("Select an EXE file first. This preview does not execute Windows programs yet.");
            } else {
                engineStatus.setText("Selected: " + selectedUri.getLastPathSegment()
                    + "\nThe native execution engine is not integrated yet. No EXE has been launched.");
            }
        });

        addGap(page, 22);
        page.addView(section("DEVICE PROFILE", ink));
        TextView device = text("Target: Android 11+\nCPU ABI: ARM64 (arm64-v8a)\nGPU target: Mali-G76 MC4", 14, muted);
        device.setPadding(0, dp(10), 0, 0);
        page.addView(device);

        addGap(page, 22);
        page.addView(section("NATIVE ENGINE", ink));
        engineStatus = text(nativeGetEngineStatus(), 14, muted);
        engineStatus.setPadding(dp(12), dp(12), dp(12), dp(12));
        engineStatus.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(10);
        page.addView(engineStatus, statusParams);

        addGap(page, 18);
        TextView note = text("Prototype 0.1.0 • Interface and JNI scaffold only", 12, muted);
        note.setGravity(Gravity.CENTER);
        page.addView(note, matchWrap());

        setContentView(scroll);
    }

    private TextView section(String title, int color) {
        TextView view = text(title, 12, color);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private void addGap(LinearLayout parent, int dpValue) {
        View gap = new View(this);
        parent.addView(gap, new LinearLayout.LayoutParams(1, dp(dpValue)));
    }

    private void openExePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, PICK_EXE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_EXE && resultCode == RESULT_OK && data != null) {
            selectedUri = data.getData();
            if (selectedUri != null) {
                getContentResolver().takePersistableUriPermission(
                    selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                selectedFile.setText("Selected file: " + selectedUri.getLastPathSegment()
                    + "\nNote: selection only; execution is not available yet.");
            }
        }
    }
}
