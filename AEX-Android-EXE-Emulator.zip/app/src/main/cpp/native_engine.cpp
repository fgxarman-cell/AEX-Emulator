#include <jni.h>

extern "C"
JNIEXPORT jstring JNICALL
Java_com_armancraft_aex_MainActivity_nativeGetEngineStatus(JNIEnv* env, jobject) {
    const char* status =
        "Native library loaded successfully.\n"
        "Status: engine scaffold only.\n"
        "Windows API, CPU translation, Wine and DirectX/Vulkan layers are not integrated.";
    return env->NewStringUTF(status);
}
