# AEX — Android EXE Emulator (Prototype 0.1.0)

A native Android app shell for a future Windows-game compatibility project.

## Current features
- Android app UI for a game launcher
- System document picker for selecting files
- ARM64-only APK configuration
- JNI/C++ native library scaffold
- GitHub Actions workflow to build a debug APK

## Important
This prototype **does not run EXE files**. Selecting an EXE only records the chosen document URI. A real engine still needs to be integrated, including a Windows compatibility layer, CPU translation where required, filesystem/runtime support, and graphics translation. FEX is primarily a Linux-on-Linux project and is not a drop-in Android game engine.

## Build using GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (including the hidden `.github` folder).
3. Open **Actions**.
4. Select **Build AEX APK** and press **Run workflow**, or push to `main`.
5. Open the completed workflow run and download the `AEX-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

## Target
- Minimum Android: 11 (API 30)
- Native ABI: `arm64-v8a`
- Initial target device: Redmi Note 8 Pro / Mali-G76 MC4

## Next development steps
1. Verify APK install and file picker on the target phone.
2. Design a safe engine bridge and runtime directory.
3. Evaluate an Android-compatible Wine/Box64/Hangover-style approach before bundling any engine.
4. Add graphics support only after the CPU/runtime layer is validated.
